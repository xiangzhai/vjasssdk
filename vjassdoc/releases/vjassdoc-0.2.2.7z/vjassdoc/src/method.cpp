/***************************************************************************
 *   Copyright (C) 2008 by Tamino Dauth                                    *
 *   tamino@cdauth.de                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <sstream>

//preperation for gettext
#include <libintl.h>
#include <locale.h>
#define _(string) gettext(string)

#include "objects.h"

namespace vjassdoc
{

Method::Method(const std::string &identifier, class SourceFile *sourceFile, unsigned int line, class DocComment *docComment, class Library *library, class Scope *scope, std::list<std::string> *parameterTypeExpressions, std::list<std::string> *parameters, const std::string &returnTypeExpression, bool isConstant, class Object *container, bool isStatic, const std::string &defaultReturnValueExpression) : m_container(container), m_isStatic(isStatic), defaultReturnValueExpression(defaultReturnValueExpression), m_defaultReturnValue(0), Function(identifier, sourceFile, line, docComment, library, scope, parameterTypeExpressions, parameters, returnTypeExpression, true, isConstant, false)
{
}

Method::Method(std::vector<const unsigned char*> &columnVector) : Function(columnVector)
{
}

void Method::init()
{
	Function::init();

	if (!this->defaultReturnValueExpression.empty())
	{
		if (Object::hasToSearchValueObject(static_cast<class Type*>(this->returnType()), this->defaultReturnValueExpression))
		{
			this->m_defaultReturnValue = this->searchObjectInList(this->defaultReturnValueExpression, Parser::Types);
		
			if (this->m_defaultReturnValue == 0)
				this->m_defaultReturnValue = this->searchObjectInList(this->defaultReturnValueExpression, Parser::FunctionInterfaces);
			
			if (this->m_defaultReturnValue == 0)
				this->m_defaultReturnValue = this->searchObjectInList(this->defaultReturnValueExpression, Parser::Interfaces);
			
			if (this->m_defaultReturnValue == 0)
				this->m_defaultReturnValue = this->searchObjectInList(this->defaultReturnValueExpression, Parser::Structs);
			
			if (this->m_defaultReturnValue != 0)
				this->defaultReturnValueExpression.clear();
		}
	}
	else
		this->defaultReturnValueExpression = '-';
}

void Method::pageNavigation(std::ofstream &file) const
{
	Function::pageNavigation(file);
	file
	<< "\t\t\t<li><a href=\"#Container\">"				<< _("Container") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Static\">"					<< _("Static") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Default return value\">"	<< _("Default return value") << "</a></li>\n"
	;
}

void Method::page(std::ofstream &file) const
{
	Function::page(file);
	file
	<< "\t\t<h2><a name=\"Container\">" << _("Container") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->container()) << "\n"
	<< "\t\t<h2><a name=\"Static\">" << _("Static") << "</a></h2>\n"
	<< "\t\t" << Object::showBooleanProperty(this->isStatic()) << "\n"
	<< "\t\t<h2><a name=\"Default return value\">" << _("Default return value") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->defaultReturnValue(), this->defaultReturnValueExpression) << "\n"
	;
}

std::string Method::sqlStatement() const
{
	std::ostringstream sstream;
	sstream
	<< Function::sqlStatement() << ", "
	<< "Container=" << Object::objectId(this->container()) << ", "
	<< "IsStatic=" << this->isStatic() << ", "
	<< "DefaultReturnValue=" << Object::objectId(this->defaultReturnValue());

	return sstream.str();
}

/* inline */ class Object* Method::container() const
{
	return this->m_container;
}

/* inline */ bool Method::isStatic() const
{
	return this->m_isStatic;
}

/* inline */ class Object* Method::defaultReturnValue() const
{
	return this->m_defaultReturnValue;
}

};
