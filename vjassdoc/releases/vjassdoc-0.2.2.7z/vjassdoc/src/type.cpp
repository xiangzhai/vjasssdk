/***************************************************************************
 *   Copyright (C) 2008 by Tamino Dauth                                    *
 *   tamino@cdauth.de                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <cctype>
#include <sstream>

//preperation for gettext
#include <libintl.h>
#include <locale.h>
#define _(string) gettext(string)

#include "objects.h"

namespace vjassdoc
{

Type::Type(const std::string &identifier, class SourceFile *sourceFile, unsigned int line, class DocComment *docComment, const std::string &typeExpression, const std::string &sizeExpression) : typeExpression(typeExpression), sizeExpression(sizeExpression), m_type(0), m_size(0), Object(identifier, sourceFile, line, docComment)
{
}

Type::Type(std::vector<const unsigned char*> &columnVector) : Object(columnVector)
{
}

void Type::init()
{
	if (!this->typeExpression.empty())
	{
		this->m_type = static_cast<Type*>(this->searchObjectInList(this->typeExpression, Parser::Types));
		
		if (this->m_type != 0)
			this->typeExpression.clear();
	}
	else
		this->typeExpression = '-';
	
	if (this->sizeExpression.empty())
	{
		this->sizeExpression = '-';
		return;
	}
	
	if (isdigit(this->sizeExpression[0])) //expression can be an integer like 43
		return;
	
	this->m_size = this->searchObjectInList(this->sizeExpression, Parser::Globals);
	
	if (this->m_size == 0)
		this->m_size = this->searchObjectInList(this->sizeExpression, Parser::Members);
	
	if (this->m_size == 0)
		this->m_size = this->searchObjectInList(this->sizeExpression, Parser::Functions);
	
	if (this->m_size == 0)
		this->m_size = this->searchObjectInList(this->sizeExpression, Parser::Methods);
	
	if (this->m_size != 0)
		this->sizeExpression.clear();
}

void Type::pageNavigation(std::ofstream &file) const
{
	file
	<< "\t\t\t<li><a href=\"#Description\">"	<< _("Description") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Source file\">"	<< _("Source file") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Inherited type\">"	<< _("Inherited type") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Size\">"			<< _("Size") << "</a></li>\n"
	;
}

void Type::page(std::ofstream &file) const
{
	file
	<< "\t\t<h2><a name=\"Description\">" << _("Description") << "</a></h2>\n"
	<< "\t\t<p>\n"
	<< "\t\t" << Object::objectPageLink(this->docComment()) << '\n'
	<< "\t\t</p>\n"
	<< "\t\t<h2><a name=\"Source file\">" << _("Source file") << "</a></h2>\n"
	<< "\t\t" << SourceFile::sourceFileLineLink(this) << '\n'
	<< "\t\t<h2><a name=\"Inherited type\">" << _("Inherited type") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->type(), this->typeExpression) << '\n'
	<< "\t\t<h2><a name=\"Size\">" << _("Size") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->size(), this->sizeExpression) << '\n'
	;
}

std::string Type::sqlStatement() const
{
	std::ostringstream sstream;
	sstream
	<< Object::sqlStatement() << ", "
	<< "Type=" << Object::objectId(this->type()) << ", "
	<< "Size=" << Object::objectId(this->size());

	return sstream.str();
}

/* inline */ class Type* Type::type() const
{
	return this->m_type;
}

/* inline */ class Object* Type::size() const
{
	return this->m_size;
}

/* inline */ int Type::sizeLiteral() const
{
	if (sizeExpression.empty() || !isdigit(sizeExpression[0])) //if it is not a literal value
		return -1;
	
	return atoi(sizeExpression.c_str());
}

};
