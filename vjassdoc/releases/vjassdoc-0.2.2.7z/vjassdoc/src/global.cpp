/***************************************************************************
 *   Copyright (C) 2008 by Tamino Dauth                                    *
 *   tamino@cdauth.de                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <cctype>
#include <sstream>

//preperation for gettext
#include <libintl.h>
#include <locale.h>
#define _(string) gettext(string)

#include "objects.h"
#include "vjassdoc.h"

namespace vjassdoc
{

Global::Global(const std::string &identifier, class SourceFile *sourceFile, unsigned int line, class DocComment *docComment, class Library *library, class Scope *scope, bool isPublic, bool isConstant, const std::string &typeExpression, const std::string &valueExpression, const std::string &sizeExpression) : m_library(library), m_scope(scope), m_isPublic(isPublic), m_isConstant(isConstant), typeExpression(typeExpression), valueExpression(valueExpression), sizeExpression(sizeExpression), m_type(0), m_value(0), m_size(0), Object(identifier, sourceFile, line, docComment)
{
}

Global::Global(std::vector<const unsigned char*> &columnVector) : Object(columnVector)
{
}

void Global::init()
{
	//Must not be empty.
	this->m_type = this->searchObjectInList(this->typeExpression, Parser::Types);
	
	if (this->m_type == 0)
		this->m_type = this->searchObjectInList(this->typeExpression, Parser::Interfaces);
	
	if (this->m_type == 0)
		this->m_type = this->searchObjectInList(this->typeExpression, Parser::Structs);
	
	if (this->m_type != 0)
		this->typeExpression.clear();
	
	this->m_value = this->findValue(this->m_type, this->valueExpression);
	this->m_size = this->findValue(Vjassdoc::getParser()->integerType(), sizeExpression);
}

void Global::pageNavigation(std::ofstream &file) const
{
	file
	<< "\t\t\t<li><a href=\"#Description\">"	<< _("Description") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Source file\">"	<< _("Source file") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Library\">"		<< _("Library") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Scope\">"			<< _("Scope") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Public\">"			<< _("Public") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Constant\">"		<< _("Constant") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Type\">"			<< _("Type") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Value\">"			<< _("Value") << "</a></li>\n"
	<< "\t\t\t<li><a href=\"#Size\">"			<< _("Size") << "</a></li>\n"
	;
}

void Global::page(std::ofstream &file) const
{
	file
	<< "\t\t<h2><a name=\"Description\">" << _("Description") << "</a></h2>\n"
	<< "\t\t<p>\n"
	<< "\t\t" << Object::objectPageLink(this->docComment()) << "\n"
	<< "\t\t</p>\n"
	<< "\t\t<h2><a name=\"Source file\">" << _("Source file") << "</a></h2>\n"
	<< "\t\t" << SourceFile::sourceFileLineLink(this) << '\n'
	<< "\t\t<h2><a name=\"Library\">" << _("Library") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->library()) << "\n"
	<< "\t\t<h2><a name=\"Scope\">" << _("Scope") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->scope()) << "\n"
	<< "\t\t<h2><a name=\"Public\">" << _("Public") << "</a></h2>\n"
	<< "\t\t" << Object::showBooleanProperty(this->isPublic()) << "\n"
	<< "\t\t<h2><a name=\"Constant\">" << _("Constant") << "</a></h2>\n"
	<< "\t\t" << Object::showBooleanProperty(this->isConstant()) << "\n"
	<< "\t\t<h2><a name=\"Type\">" << _("Type") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->type(), this->typeExpression) << "\n"
	<< "\t\t<h2><a name=\"Value\">" << _("Value") << "</a></h2>\n"
	;
	
	if (this->value() != 0)
		file << "\t\t" << Object::objectPageLink(this->value()) << this->valueExpression << "\n";
	else
		file << "\t\t" << this->valueExpression << "\n";
	
	file
	<< "\t\t<h2><a name=\"Size\">" << _("Size") << "</a></h2>\n"
	<< "\t\t" << Object::objectPageLink(this->size(), this->sizeExpression) << "\n"
	;
}

std::string Global::sqlStatement() const
{
	std::ostringstream sstream;
	sstream
	<< Object::sqlStatement() << ", "
	<< "Library=" << Object::objectId(this->library()) << ", "
	<< "Scope=" << Object::objectId(this->scope()) << ", "
	<< "IsPublic=" << this->isPublic() << ", "
	<< "IsConstant=" << this->isConstant() << ", "
	<< "Type=" << Object::objectId(this->type()) << ", "
	<< "Value=" << this->value() << ", "
	<< "Size=" << this->size();
	
	return sstream.str();
}

/* inline */ Library* Global::library() const
{
	return this->m_library;
}

/* inline */ Scope* Global::scope() const
{
	return this->m_scope;
}

/* inline */ bool Global::isPublic() const
{
	return this->m_isPublic;
}

/* inline */ bool Global::isConstant() const
{
	return this->m_isConstant;
}

/* inline */ Object* Global::type() const
{
	return this->m_type;
}

/* inline */ Object* Global::value() const
{
	return this->m_value;
}

/* inline */ std::string Global::valueLiteral() const
{
	return this->valueExpression;
}

/* inline */ Object* Global::size() const
{
	return this->m_size;
}

/* inline */ int Global::sizeLiteral() const
{
	if (sizeExpression.empty() || !isdigit(sizeExpression[0])) //if it is not a literal value
		return -1;
	
	return atoi(sizeExpression.c_str());
}

};
